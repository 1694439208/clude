package com.zl; 
public class Test 
{ 
    public Test() 
   { 
   } 
   public int GetData() 
   {  
         return 10; 
    } 
}